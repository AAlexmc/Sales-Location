import pandas as pd
import random
import tkinter as tk
from tkinter import filedialog

# Configuration
communities = ['Barcelona', 'Gerona', 'Lérida', 'Tarragona']
products = ['Laptop', 'Phone', 'Printer', 'Television', 'Washing Machine']
lifespan = {
    'Laptop': 3.5,
    'Phone': 2.5,
    'Printer': 5,
    'Television': 8,
    'Washing Machine': 13
}
num_people_per_community = 100  # Reduced for quick generation

# Function to generate purchases with variations
def generate_purchases():
    purchases = {product: random.randint(0, 3) for product in products}
    return purchases

# Function to save the CSV file
def save_csv():
    file_path = filedialog.asksaveasfilename(defaultextension=".csv", 
                                               filetypes=[("CSV files", "*.csv")])
    if file_path:
        # Generate data for each community
        data = []
        histories = set()  # To ensure no duplicates

        for community in communities:
            for person_id in range(1, num_people_per_community + 1):
                while True:
                    income = random.randint(20000, 100000)
                    age = random.randint(18, 70)
                    purchases = generate_purchases()
                    purchases_str = str(purchases)

                    # Check if the purchase history already exists
                    if purchases_str not in histories:
                        histories.add(purchases_str)
                        break

                max_product = max(purchases, key=purchases.get)
                max_frequency = purchases[max_product]
                
                # Check if they have purchased before the programmed obsolescence
                repeat_buyer = any(
                    purchases[product] > 0 and lifespan[product] > 6
                    for product in products
                )
                
                data.append({
                    'ID': f'{community[:3].upper()}{person_id:02d}',  # Unique ID
                    'Community': community,
                    'Income': income,
                    'Age': age,
                    'Purchases': purchases_str,  # Convert to string to save in CSV
                    'Most Purchased Product': max_product,  # Changed here
                    'Most Purchased Frequency': max_frequency,
                    'Repeat Buyer': repeat_buyer
                })

        # Create DataFrame
        df = pd.DataFrame(data)

        # Save DataFrame to a CSV file
        df.to_csv(file_path, index=False)
        print(f"File '{file_path}' successfully generated.")

# Create main window
window = tk.Tk()
window.title("Generate Database")
window.geometry("300x150")

# Button to save the CSV file
save_button = tk.Button(window, text="Save CSV", command=save_csv)
save_button.pack(pady=20)

# Run the application
window.mainloop()