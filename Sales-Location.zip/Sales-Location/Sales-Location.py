import pandas as pd
import ast
import plotly.express as px
from flask import Flask, render_template, request, redirect, url_for, flash
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
import webbrowser
import threading

app = Flask(__name__)
app.secret_key = 'supersecretkey'  # Necessary for using flash messages

df = None  # Global DataFrame
model = None  # Global AI model

@app.route('/')
def index():
    products = df['Most Purchased Product'].unique() if df is not None else []
    return render_template('index.html', products=products)

@app.route('/upload', methods=['POST'])
def upload_file():
    global df
    file = request.files['file']
    if file:
        df = pd.read_csv(file)
        df['Purchases'] = df['Purchases'].apply(ast.literal_eval)  # Convert the purchases column from string to dict
        train_model()  # Train the AI model
        flash(f"File '{file.filename}' uploaded successfully.")
        return redirect(url_for('index'))
    flash('No file selected.')
    return redirect(url_for('index'))

def train_model():
    global model
    if df is not None:
        df['Total Purchases'] = df['Purchases'].apply(lambda x: sum(x.values()))
        X = df[['Total Purchases', 'Most Purchased Frequency']]
        y = df['Most Purchased Product']
        
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        model = RandomForestClassifier(n_estimators=100, random_state=42)
        model.fit(X_train, y_train)
        
        y_pred = model.predict(X_test)
        accuracy = accuracy_score(y_test, y_pred)
        print(f"Model accuracy: {accuracy:.2f}")

@app.route('/analyze', methods=['POST'])
def analyze_data():
    global df
    if df is None:
        return 'Please upload a CSV file first.'
    
    product_to_sell = request.form['product']
    if product_to_sell not in df['Most Purchased Product'].unique():
        return 'Invalid product. Make sure to select one of the available products.'

    community_product_ranking = df.groupby(['Community', 'Most Purchased Product']).size().unstack(fill_value=0)
    total_products = df['Most Purchased Product'].value_counts()
    most_sold_product = total_products.idxmax()
    least_sold_product = total_products.idxmin()

    results = {}
    for community in df['Community'].unique():
        total_purchases = df[df['Community'] == community]['Purchases'].apply(lambda x: x[product_to_sell]).sum()
        total_people = df[df['Community'] == community].shape[0]
        purchase_percentage = (total_purchases / (total_people * 6)) * 100
        repurchase_probability = df[(df['Community'] == community) & (df['Purchases'].apply(lambda x: x[product_to_sell] > 0))].shape[0] / total_people * 100
        
        results[community] = {
            'Purchase Percentage': purchase_percentage,
            'Number of Products Sold': total_purchases,
            'Repurchase Probability': repurchase_probability
        }
    
    results_df = pd.DataFrame(results).T.reset_index()
    fig = px.bar(results_df, x='index', y=['Purchase Percentage', 'Number of Products Sold', 'Repurchase Probability'],
                 title=f'Sales Analysis for Product: {product_to_sell} over 6 years',
                 labels={'value': 'Values', 'variable': 'Metric'},
                 barmode='group')
    graph_html = fig.to_html(full_html=False)
    
    results_text = f"<h2>Community and Product Ranking:</h2><pre>{community_product_ranking.to_html()}</pre>"
    results_text += f"<h2>Most Sold Product: {most_sold_product}</h2>"
    results_text += f"<h2>Least Sold Product: {least_sold_product}</h2>"
    results_text += f"<h2>Results for the product '{product_to_sell}':</h2>"
    for community, result in results.items():
        results_text += f"<h3>{community}:</h3>"
        results_text += f"<p>Purchase Percentage: {result['Purchase Percentage']:.2f}%</p>"
        results_text += f"<p>Number of Products Sold: {result['Number of Products Sold']}</p>"
        results_text += f"<p>Repurchase Probability: {result['Repurchase Probability']:.2f}%</p>"
    best_community = max(results, key=lambda x: results[x]['Number of Products Sold'])
    results_text += f"<h2>The best community to sell '{product_to_sell}' is: {best_community}</h2>"
    
    return render_template('results.html', graph_html=graph_html, results_text=results_text)

def open_browser():
    webbrowser.open_new('http://127.0.0.1:5000/')

if __name__ == '__main__':
    threading.Timer(1.25, open_browser).start()
    app.run(debug=True)